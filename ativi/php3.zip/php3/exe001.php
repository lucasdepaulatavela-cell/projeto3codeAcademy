<?php

$i = 10;

while ($i != 0){
    echo $i;
    echo "\n";
    $i -= 1;
}

?>